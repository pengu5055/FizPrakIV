Poskus izvajan s funkcijskim generatorjem Gwinstek SFG-2120 z nastavitvami:

  TTL signal 400Hz
  offset 0
  max amplituda

Osciloskop 16 vzorcno povprecenje.

OPAZKA: Kontakti na preklopniku so zelo slabi in uspostavljanje kontakta je pogosto vprasljivo.
